import { LogoConcepts } from './branding/LogoConcepts';
import { BrandStylesheet } from './branding/BrandStylesheet';
import { BusinessCard } from './branding/BusinessCard';
import { SocialMediaKit } from './branding/SocialMediaKit';

export function BrandingSection() {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="mb-16">
        <h2 className="text-black mb-4">Logo & Branding Package</h2>
        <p className="text-zinc-600 max-w-2xl">
          Complete brand identity systems from concept to delivery. Modern, bold, and premium design solutions
          that make your brand unforgettable.
        </p>
      </div>

      <div className="space-y-24">
        {/* Logo Concepts */}
        <div>
          <h3 className="text-black mb-8">Logo Concepts</h3>
          <LogoConcepts />
        </div>

        {/* Brand Stylesheet */}
        <div>
          <h3 className="text-black mb-8">Brand Style Guide</h3>
          <BrandStylesheet />
        </div>

        {/* Business Card */}
        <div>
          <h3 className="text-black mb-8">Business Card Mockups</h3>
          <BusinessCard />
        </div>

        {/* Social Media Kit */}
        <div>
          <h3 className="text-black mb-8">Social Media Kit</h3>
          <SocialMediaKit />
        </div>
      </div>
    </div>
  );
}
