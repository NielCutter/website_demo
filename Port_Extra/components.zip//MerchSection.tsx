import { TShirtGraphics } from './merch/TShirtGraphics';
import { ShirtMockups } from './merch/ShirtMockups';

export function MerchSection() {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="mb-16">
        <h2 className="text-black mb-4">T-Shirt & Merch Design Package</h2>
        <p className="text-zinc-600 max-w-2xl">
          Custom graphic designs for apparel and merchandise. From vintage retro to bold contemporary styles,
          complete with photorealistic mockups.
        </p>
      </div>

      <div className="space-y-24">
        <div>
          <h3 className="text-black mb-8">Graphic Design Samples</h3>
          <TShirtGraphics />
        </div>

        <div>
          <h3 className="text-black mb-8">Premium Mockups</h3>
          <ShirtMockups />
        </div>
      </div>
    </div>
  );
}
