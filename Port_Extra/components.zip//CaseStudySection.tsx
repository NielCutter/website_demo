import { ArrowRight, Check, TrendingUp } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function CaseStudySection() {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="mb-16">
        <h2 className="text-black mb-4">Case Studies & Presentations</h2>
        <p className="text-zinc-600 max-w-2xl">
          Professional project presentations showcasing problem-solving approach,
          design process, and measurable results.
        </p>
      </div>

      <div className="space-y-16">
        {/* Case Study 1 - E-commerce Redesign */}
        <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
          <div className="bg-gradient-to-r from-black to-zinc-800 text-white p-8">
            <div className="max-w-3xl">
              <div className="text-zinc-400 mb-2">CASE STUDY 01</div>
              <h3 className="text-white mb-4">E-commerce Platform Redesign</h3>
              <p className="text-zinc-300">
                Complete overhaul of an outdated e-commerce experience, focusing on conversion optimization
                and modern aesthetics.
              </p>
            </div>
          </div>

          <div className="p-8">
            {/* Problem → Solution → Result */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <ProcessCard
                number="01"
                title="Problem"
                description="Low conversion rate (1.2%), outdated UI, poor mobile experience"
                icon="❌"
              />
              <ProcessCard
                number="02"
                title="Solution"
                description="Complete redesign with focus on UX, responsive design, and checkout optimization"
                icon="💡"
              />
              <ProcessCard
                number="03"
                title="Result"
                description="Conversion rate increased to 3.8%, 45% more mobile sales"
                icon="✅"
              />
            </div>

            {/* Before/After Comparison */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <div>
                <div className="text-zinc-500 mb-3">Before Redesign</div>
                <div className="aspect-video bg-zinc-100 rounded-lg border border-zinc-300 p-4">
                  <div className="bg-white h-full rounded border border-zinc-200 p-3 space-y-2">
                    <div className="h-4 bg-zinc-300 rounded w-1/2" />
                    <div className="grid grid-cols-3 gap-2 flex-1">
                      <div className="bg-zinc-200 rounded" />
                      <div className="bg-zinc-200 rounded" />
                      <div className="bg-zinc-200 rounded" />
                    </div>
                  </div>
                </div>
                <div className="mt-3 space-y-1">
                  <div className="flex items-center gap-2 text-red-600">
                    <div className="w-1.5 h-1.5 bg-red-600 rounded-full" />
                    <span>Cluttered interface</span>
                  </div>
                  <div className="flex items-center gap-2 text-red-600">
                    <div className="w-1.5 h-1.5 bg-red-600 rounded-full" />
                    <span>Poor navigation</span>
                  </div>
                  <div className="flex items-center gap-2 text-red-600">
                    <div className="w-1.5 h-1.5 bg-red-600 rounded-full" />
                    <span>Low conversion</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-zinc-500 mb-3">After Redesign</div>
                <div className="aspect-video bg-zinc-900 rounded-lg border border-zinc-700 p-4">
                  <div className="bg-white h-full rounded shadow-lg p-3 space-y-2">
                    <div className="h-3 bg-black rounded w-1/3" />
                    <div className="grid grid-cols-3 gap-2 flex-1">
                      <div className="bg-zinc-100 rounded border border-zinc-200" />
                      <div className="bg-zinc-100 rounded border border-zinc-200" />
                      <div className="bg-zinc-100 rounded border border-zinc-200" />
                    </div>
                    <div className="h-6 bg-black rounded" />
                  </div>
                </div>
                <div className="mt-3 space-y-1">
                  <div className="flex items-center gap-2 text-green-600">
                    <Check size={14} />
                    <span>Clean, modern layout</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-600">
                    <Check size={14} />
                    <span>Intuitive navigation</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-600">
                    <Check size={14} />
                    <span>3x conversion rate</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MetricCard label="Conversion Rate" value="+217%" />
              <MetricCard label="Mobile Traffic" value="+45%" />
              <MetricCard label="Avg. Order Value" value="+28%" />
              <MetricCard label="Page Speed" value="+60%" />
            </div>
          </div>
        </div>

        {/* Case Study 2 - Brand Identity */}
        <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-zinc-200">
            <div className="bg-white p-8">
              <div className="text-zinc-500 mb-2">CASE STUDY 02</div>
              <h4 className="text-black mb-4">Tech Startup Brand Identity</h4>
              <p className="text-zinc-600 mb-6">
                Created a complete brand identity system for an emerging tech startup,
                from logo design to brand guidelines and marketing materials.
              </p>

              <div className="space-y-4 mb-6">
                <DeliverableItem text="Logo design (3 concepts)" />
                <DeliverableItem text="Brand style guide (24 pages)" />
                <DeliverableItem text="Business cards & stationery" />
                <DeliverableItem text="Social media templates" />
                <DeliverableItem text="Website design mockups" />
              </div>

              <div className="bg-zinc-50 rounded-lg p-4">
                <div className="text-zinc-600 mb-2">Client Feedback</div>
                <p className="text-black italic">
                  "The brand identity exceeded our expectations. We've seen a 40% increase
                  in brand recognition within the first quarter."
                </p>
                <div className="text-zinc-600 mt-2">— CEO, TechFlow Inc.</div>
              </div>
            </div>

            <div className="bg-zinc-50 p-8 flex items-center justify-center">
              <div className="grid grid-cols-2 gap-4 w-full max-w-md">
                <div className="aspect-square bg-white rounded-lg shadow-lg p-6 flex items-center justify-center">
                  <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center text-white">
                    T
                  </div>
                </div>
                <div className="aspect-square bg-black rounded-lg shadow-lg p-6 flex items-center justify-center">
                  <div className="w-16 h-16 bg-white rounded flex items-center justify-center text-black">
                    TF
                  </div>
                </div>
                <div className="col-span-2 bg-gradient-to-r from-black to-zinc-700 rounded-lg shadow-lg p-6 flex items-center justify-center text-white">
                  <div>Brand Guidelines</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Presentation Slides Preview */}
        <div>
          <h4 className="text-black mb-8">Presentation Slide Templates</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <SlidePreview
              title="Title Slide"
              content={
                <div className="text-center">
                  <h5 className="text-black mb-2">Project Title</h5>
                  <div className="text-zinc-600">Subtitle Here</div>
                </div>
              }
            />
            <SlidePreview
              title="Problem Statement"
              content={
                <div>
                  <div className="text-black mb-3">The Challenge</div>
                  <div className="space-y-2">
                    <div className="h-2 bg-zinc-200 rounded w-full" />
                    <div className="h-2 bg-zinc-200 rounded w-5/6" />
                    <div className="h-2 bg-zinc-200 rounded w-4/6" />
                  </div>
                </div>
              }
            />
            <SlidePreview
              title="Visual Showcase"
              content={
                <div className="grid grid-cols-2 gap-2">
                  <div className="aspect-square bg-zinc-200 rounded" />
                  <div className="aspect-square bg-zinc-200 rounded" />
                </div>
              }
            />
            <SlidePreview
              title="Metrics & Results"
              content={
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-600">Metric 1</span>
                    <span className="text-green-600">+45%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-600">Metric 2</span>
                    <span className="text-green-600">+32%</span>
                  </div>
                </div>
              }
            />
            <SlidePreview
              title="Timeline"
              content={
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-black rounded-full" />
                      <div className="h-2 bg-zinc-200 rounded flex-1" />
                    </div>
                  ))}
                </div>
              }
            />
            <SlidePreview
              title="Contact Slide"
              content={
                <div className="text-center">
                  <div className="w-12 h-12 bg-black rounded-full mx-auto mb-3 flex items-center justify-center text-white">
                    M
                  </div>
                  <div className="text-black">Get in Touch</div>
                </div>
              }
            />
          </div>
        </div>

        {/* Pricing Table */}
        <div>
          <h4 className="text-black mb-8">Pricing Table Example</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <PricingCard
              name="Starter"
              price="$499"
              features={[
                'Logo design (2 concepts)',
                'Basic brand guidelines',
                'Business card design',
                '2 revision rounds'
              ]}
            />
            <PricingCard
              name="Professional"
              price="$1,299"
              features={[
                'Logo design (3 concepts)',
                'Complete brand guidelines',
                'Business stationery set',
                'Social media templates',
                'Unlimited revisions'
              ]}
              featured
            />
            <PricingCard
              name="Enterprise"
              price="Custom"
              features={[
                'Everything in Professional',
                'Brand strategy consulting',
                'Marketing materials',
                'Website design',
                'Dedicated support'
              ]}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function ProcessCard({ number, title, description, icon }: {
  number: string;
  title: string;
  description: string;
  icon: string;
}) {
  return (
    <div className="bg-zinc-50 rounded-lg p-6 relative">
      <div className="text-4xl mb-3">{icon}</div>
      <div className="text-zinc-400 mb-2">Step {number}</div>
      <h5 className="text-black mb-2">{title}</h5>
      <p className="text-zinc-600">{description}</p>
    </div>
  );
}

function MetricCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-zinc-50 rounded-lg p-4 text-center border border-zinc-200">
      <div className="flex items-center justify-center gap-1 text-green-600 mb-2">
        <TrendingUp size={18} />
        <span className="text-2xl">{value}</span>
      </div>
      <div className="text-zinc-600">{label}</div>
    </div>
  );
}

function DeliverableItem({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-6 h-6 bg-black rounded-full flex items-center justify-center text-white flex-shrink-0">
        <Check size={14} />
      </div>
      <span className="text-zinc-700">{text}</span>
    </div>
  );
}

function SlidePreview({ title, content }: { title: string; content: React.ReactNode }) {
  return (
    <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-video bg-white border-b border-zinc-200 p-6 flex items-center justify-center">
        {content}
      </div>
      <div className="p-4 bg-zinc-50 text-center">
        <span className="text-zinc-600">{title}</span>
      </div>
    </div>
  );
}

function PricingCard({ name, price, features, featured }: {
  name: string;
  price: string;
  features: string[];
  featured?: boolean;
}) {
  return (
    <div className={`rounded-xl p-8 ${
      featured 
        ? 'bg-black text-white shadow-xl scale-105' 
        : 'bg-white border border-zinc-200'
    }`}>
      {featured && (
        <div className="text-center mb-4 px-3 py-1 bg-white/20 rounded-full inline-block">
          Most Popular
        </div>
      )}
      <div className="text-center mb-6">
        <div className={`mb-2 ${featured ? 'text-white' : 'text-zinc-600'}`}>{name}</div>
        <div className={`mb-1 ${featured ? 'text-white' : 'text-black'}`}>{price}</div>
        <div className={featured ? 'text-zinc-400' : 'text-zinc-500'}>per project</div>
      </div>
      <ul className="space-y-3 mb-6">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start gap-2">
            <Check size={18} className={`mt-0.5 flex-shrink-0 ${featured ? 'text-white' : 'text-black'}`} />
            <span className={featured ? 'text-white' : 'text-zinc-700'}>{feature}</span>
          </li>
        ))}
      </ul>
      <button className={`w-full py-3 rounded-lg transition-colors ${
        featured
          ? 'bg-white text-black hover:bg-zinc-100'
          : 'bg-black text-white hover:bg-zinc-800'
      }`}>
        Get Started
      </button>
    </div>
  );
}
