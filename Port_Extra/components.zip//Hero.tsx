import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <div className="min-h-screen flex items-center justify-center px-6 bg-gradient-to-b from-white to-zinc-50">
      <div className="max-w-5xl mx-auto text-center">
        <div className="inline-block px-4 py-2 bg-black text-white rounded-full mb-8">
          Software Engineer • Hyperrealistic Illustrator • Creative Designer
        </div>
        
        <h1 className="mb-6 text-black">
          Crafting Digital Experiences<br />& Visual Masterpieces
        </h1>
        
        <p className="text-zinc-600 mb-12 max-w-2xl mx-auto">
          From pixel-perfect interfaces to hyperrealistic illustrations and premium brand identities.
          Explore a complete suite of creative services backed by technical excellence.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <button 
            onClick={() => document.getElementById('web-dev')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-black text-white rounded-lg hover:bg-zinc-800 transition-colors flex items-center gap-2"
          >
            View Portfolio <ArrowRight size={20} />
          </button>
          <button 
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 border border-zinc-300 text-black rounded-lg hover:border-black transition-colors"
          >
            Get in Touch
          </button>
        </div>

        {/* Service Pills */}
        <div className="mt-20 flex flex-wrap items-center justify-center gap-3">
          {[
            'Web Development',
            'UI/UX Design',
            'Brand Identity',
            'Hyperrealistic Illustration',
            'Merch Design',
            'Product Mockups'
          ].map((service) => (
            <div key={service} className="px-4 py-2 bg-white border border-zinc-200 rounded-full text-zinc-700">
              {service}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
