import { Package, ShoppingBag, Smartphone, Shirt } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function MockupsSection() {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="mb-16">
        <h2 className="text-black mb-4">Product Mockups & Brand Showcase</h2>
        <p className="text-zinc-600 max-w-2xl">
          Photorealistic mockups for apparel, packaging, and brand materials.
          Professional presentation assets for your products and services.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {/* Apparel Mockups */}
        <div className="bg-white border border-zinc-200 rounded-xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-black text-white rounded-lg">
              <Shirt size={20} />
            </div>
            <h4 className="text-black">Apparel Collection</h4>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <ApparelMockup item="T-Shirt" />
            <ApparelMockup item="Hoodie" />
            <ApparelMockup item="Cap" />
            <ApparelMockup item="Socks" />
          </div>
          
          <div className="text-zinc-600">
            High-quality mockups for all apparel types with customizable colors and graphics
          </div>
        </div>

        {/* Packaging Mockups */}
        <div className="bg-white border border-zinc-200 rounded-xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-black text-white rounded-lg">
              <Package size={20} />
            </div>
            <h4 className="text-black">Packaging Design</h4>
          </div>
          
          <div className="aspect-square bg-zinc-50 rounded-lg mb-6 relative overflow-hidden">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1603712521905-3c68898026f2?w=600"
              alt="Packaging"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 flex items-center justify-center bg-black/20">
              <div className="w-32 h-32 bg-white rounded-lg shadow-2xl flex items-center justify-center">
                <div className="w-24 h-24 bg-black rounded flex items-center justify-center text-white">
                  LOGO
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-zinc-600">
            Premium box packaging with embossed logo and custom inserts
          </div>
        </div>
      </div>

      {/* Full Width Mockups */}
      <div className="space-y-8">
        {/* Tote Bag */}
        <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-zinc-200">
            <div className="bg-zinc-50 p-12 flex items-center justify-center">
              <div className="relative">
                <div className="w-64 h-80 bg-white border-2 border-zinc-300 rounded-t-lg shadow-xl flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-24 h-24 bg-black rounded-full mx-auto mb-4 flex items-center justify-center text-white">
                      M
                    </div>
                    <div className="text-black tracking-wider">STUDIO</div>
                  </div>
                </div>
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-40 h-8 bg-zinc-300 rounded-full border-2 border-zinc-400" />
              </div>
            </div>
            <div className="bg-white p-12 flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-4">
                <ShoppingBag size={24} />
                <h4 className="text-black">Tote Bag Design</h4>
              </div>
              <p className="text-zinc-600 mb-6">
                Eco-friendly cotton tote bags with premium screen printing.
                Perfect for retail, events, and brand merchandise.
              </p>
              <div className="space-y-2">
                <DetailLine label="Material" value="100% Organic Cotton" />
                <DetailLine label="Dimensions" value="15&quot; x 16&quot; x 3&quot;" />
                <DetailLine label="Print Area" value="10&quot; x 12&quot;" />
                <DetailLine label="Handle Type" value="Reinforced Straps" />
              </div>
            </div>
          </div>
        </div>

        {/* Sticker Pack */}
        <div className="bg-white border border-zinc-200 rounded-xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <h4 className="text-black">Sticker Pack Collection</h4>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="aspect-square bg-white border-2 border-zinc-200 rounded-lg shadow-md flex items-center justify-center hover:scale-105 transition-transform">
                <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center text-white">
                  {i + 1}
                </div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-zinc-50 rounded-lg p-4 text-center">
              <div className="text-black mb-1">Die-Cut Stickers</div>
              <div className="text-zinc-600">Custom shapes</div>
            </div>
            <div className="bg-zinc-50 rounded-lg p-4 text-center">
              <div className="text-black mb-1">Weather Resistant</div>
              <div className="text-zinc-600">Waterproof vinyl</div>
            </div>
            <div className="bg-zinc-50 rounded-lg p-4 text-center">
              <div className="text-black mb-1">Various Sizes</div>
              <div className="text-zinc-600">2" to 6" diameter</div>
            </div>
          </div>
        </div>

        {/* Phone Wallpaper */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <PhoneWallpaper
            title="Dark Minimal"
            bgClass="bg-black"
            content={
              <div className="text-white text-center">
                <div className="w-16 h-16 border-2 border-white rounded-full mx-auto mb-4" />
                <div style={{ fontSize: '24px', letterSpacing: '4px' }}>MINIMAL</div>
              </div>
            }
          />
          <PhoneWallpaper
            title="Gradient Flow"
            bgClass="bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400"
            content={
              <div className="text-white text-center">
                <div style={{ fontSize: '32px', fontWeight: '900' }}>FLOW</div>
              </div>
            }
          />
          <PhoneWallpaper
            title="Geometric Pattern"
            bgClass="bg-zinc-100"
            content={
              <div className="text-black text-center">
                <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
                  <rect width="80" height="80" fill="url(#pattern)" />
                  <defs>
                    <pattern id="pattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                      <rect width="20" height="20" fill="none" stroke="black" strokeWidth="1" />
                    </pattern>
                  </defs>
                </svg>
              </div>
            }
          />
        </div>

        {/* Poster Design */}
        <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-zinc-200">
            <div className="bg-zinc-900 p-12 flex items-center justify-center">
              <div className="w-full max-w-sm aspect-[2/3] bg-white rounded-lg shadow-2xl p-8 flex flex-col justify-between">
                <div>
                  <div className="text-xs tracking-wider text-zinc-500 mb-2">SPRING COLLECTION</div>
                  <h3 className="text-black mb-4">Modern<br />Minimalism</h3>
                </div>
                <div>
                  <div className="h-px bg-zinc-200 mb-4" />
                  <div className="text-zinc-600">Limited Edition 2025</div>
                </div>
              </div>
            </div>
            <div className="bg-white p-12 flex flex-col justify-center">
              <h4 className="text-black mb-4">Poster & Banner Layouts</h4>
              <p className="text-zinc-600 mb-6">
                Eye-catching poster designs for events, campaigns, and promotional materials.
                Available in multiple sizes and orientations.
              </p>
              <div className="space-y-2">
                <DetailLine label="Standard Sizes" value="18x24&quot;, 24x36&quot;, 27x40&quot;" />
                <DetailLine label="Orientation" value="Portrait & Landscape" />
                <DetailLine label="Format" value="Print-ready PDF, PNG" />
                <DetailLine label="Resolution" value="300 DPI" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ApparelMockup({ item }: { item: string }) {
  return (
    <div className="aspect-square bg-zinc-50 rounded-lg flex items-center justify-center border border-zinc-200 hover:shadow-md transition-shadow">
      <div className="text-center">
        <div className="w-16 h-16 bg-black rounded-lg mx-auto mb-2" />
        <div className="text-zinc-700">{item}</div>
      </div>
    </div>
  );
}

function DetailLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between pb-2 border-b border-zinc-100">
      <span className="text-zinc-500">{label}</span>
      <span className="text-black">{value}</span>
    </div>
  );
}

function PhoneWallpaper({ title, bgClass, content }: {
  title: string;
  bgClass: string;
  content: React.ReactNode;
}) {
  return (
    <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
      <div className="p-6 flex items-center justify-center bg-zinc-50">
        <div className="w-40 aspect-[9/19.5] bg-black rounded-3xl p-1 shadow-xl">
          <div className={`w-full h-full ${bgClass} rounded-[20px] flex items-center justify-center p-4`}>
            {content}
          </div>
        </div>
      </div>
      <div className="p-4 text-center border-t border-zinc-200">
        <div className="text-black mb-1">{title}</div>
        <div className="text-zinc-600">1170 × 2532px</div>
      </div>
    </div>
  );
}