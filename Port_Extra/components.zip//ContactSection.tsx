import { Mail, MessageSquare, Calendar, Github, Linkedin, Twitter } from 'lucide-react';

export function ContactSection() {
  return (
    <div className="max-w-4xl mx-auto px-6 text-center">
      <div className="mb-12">
        <h2 className="text-white mb-4">Let's Work Together</h2>
        <p className="text-zinc-400 max-w-2xl mx-auto">
          Ready to bring your vision to life? Whether it's web development, illustration,
          or complete brand identity, let's create something exceptional.
        </p>
      </div>

      {/* Contact Methods */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <ContactMethod
          icon={<Mail size={24} />}
          title="Email Me"
          description="hello@portfolio.com"
          link="mailto:hello@portfolio.com"
        />
        <ContactMethod
          icon={<MessageSquare size={24} />}
          title="Let's Chat"
          description="Schedule a call"
          link="#"
        />
        <ContactMethod
          icon={<Calendar size={24} />}
          title="Book a Meeting"
          description="Calendar booking"
          link="#"
        />
      </div>

      {/* Contact Form */}
      <div className="bg-white rounded-xl p-8 mb-12 text-left">
        <h4 className="text-black mb-6 text-center">Send a Message</h4>
        <form className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-zinc-700 mb-2">Name</label>
              <input
                type="text"
                placeholder="Your name"
                className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:border-black"
              />
            </div>
            <div>
              <label className="block text-zinc-700 mb-2">Email</label>
              <input
                type="email"
                placeholder="your@email.com"
                className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:border-black"
              />
            </div>
          </div>

          <div>
            <label className="block text-zinc-700 mb-2">Service Interested In</label>
            <select className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:border-black">
              <option>Select a service</option>
              <option>Web Development</option>
              <option>Logo & Branding</option>
              <option>Hyperrealistic Illustration</option>
              <option>T-Shirt & Merch Design</option>
              <option>Product Mockups</option>
              <option>Multiple Services</option>
            </select>
          </div>

          <div>
            <label className="block text-zinc-700 mb-2">Project Budget</label>
            <select className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:border-black">
              <option>Select budget range</option>
              <option>$500 - $1,000</option>
              <option>$1,000 - $2,500</option>
              <option>$2,500 - $5,000</option>
              <option>$5,000 - $10,000</option>
              <option>$10,000+</option>
            </select>
          </div>

          <div>
            <label className="block text-zinc-700 mb-2">Message</label>
            <textarea
              rows={6}
              placeholder="Tell me about your project..."
              className="w-full px-4 py-3 border border-zinc-300 rounded-lg focus:outline-none focus:border-black resize-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-black text-white rounded-lg hover:bg-zinc-800 transition-colors"
          >
            Send Message
          </button>
        </form>
      </div>

      {/* Social Links */}
      <div>
        <div className="text-zinc-400 mb-6">Connect With Me</div>
        <div className="flex items-center justify-center gap-4">
          <SocialLink icon={<Github size={20} />} href="#" />
          <SocialLink icon={<Linkedin size={20} />} href="#" />
          <SocialLink icon={<Twitter size={20} />} href="#" />
          <SocialLink icon={<Mail size={20} />} href="mailto:hello@portfolio.com" />
        </div>
      </div>

      {/* Availability Status */}
      <div className="mt-12 inline-flex items-center gap-3 px-6 py-3 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
        <span className="text-white">Available for new projects</span>
      </div>
    </div>
  );
}

function ContactMethod({ icon, title, description, link }: {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
}) {
  return (
    <a
      href={link}
      className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 hover:bg-white/10 transition-colors group"
    >
      <div className="w-12 h-12 bg-white text-black rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <div className="text-white mb-2">{title}</div>
      <div className="text-zinc-400">{description}</div>
    </a>
  );
}

function SocialLink({ icon, href }: { icon: React.ReactNode; href: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="w-12 h-12 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg flex items-center justify-center text-white hover:bg-white hover:text-black transition-colors"
    >
      {icon}
    </a>
  );
}
