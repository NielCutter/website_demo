import { HyperrealisticPortrait } from './illustration/HyperrealisticPortrait';
import { FullBodyIllustration } from './illustration/FullBodyIllustration';
import { FashionConcept } from './illustration/FashionConcept';
import { CharacterConcept } from './illustration/CharacterConcept';
import { BeforeAfter } from './illustration/BeforeAfter';

export function IllustrationSection() {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="mb-16">
        <h2 className="text-black mb-4">Illustration Package</h2>
        <p className="text-zinc-600 max-w-2xl">
          Hyperrealistic digital illustrations with meticulous attention to detail.
          From portrait work to full character concepts and fashion illustration.
        </p>
      </div>

      <div className="space-y-24">
        <div>
          <h3 className="text-black mb-8">Hyperrealistic Portrait</h3>
          <HyperrealisticPortrait />
        </div>

        <div>
          <h3 className="text-black mb-8">Full-Body Character Illustration</h3>
          <FullBodyIllustration />
        </div>

        <div>
          <h3 className="text-black mb-8">Stylized Fashion Concept</h3>
          <FashionConcept />
        </div>

        <div>
          <h3 className="text-black mb-8">Character Concept (Techwear / Streetwear)</h3>
          <CharacterConcept />
        </div>

        <div>
          <h3 className="text-black mb-8">Before / After Enhancement</h3>
          <BeforeAfter />
        </div>
      </div>
    </div>
  );
}
