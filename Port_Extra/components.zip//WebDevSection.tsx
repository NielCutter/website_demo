import { AdminDashboard } from './web-samples/AdminDashboard';
import { EcommerceSite } from './web-samples/EcommerceSite';
import { FigmaToLive } from './web-samples/FigmaToLive';
import { TechFashionLanding } from './web-samples/TechFashionLanding';
import { ResponsivePreviews } from './web-samples/ResponsivePreviews';

export function WebDevSection() {
  return (
    <div className="max-w-7xl mx-auto px-6">
      <div className="mb-16">
        <h2 className="text-black mb-4">Web Development Package</h2>
        <p className="text-zinc-600 max-w-2xl">
          Modern, responsive, and performant web applications with pixel-perfect design implementation.
          From admin dashboards to e-commerce platforms.
        </p>
      </div>

      <div className="space-y-24">
        {/* Admin Dashboard */}
        <div>
          <h3 className="text-black mb-8">Modern Admin Dashboard</h3>
          <AdminDashboard />
        </div>

        {/* E-commerce Site */}
        <div>
          <h3 className="text-black mb-8">E-commerce Apparel Site</h3>
          <EcommerceSite />
        </div>

        {/* Figma to Live */}
        <div>
          <h3 className="text-black mb-8">Figma → Live Site Preview</h3>
          <FigmaToLive />
        </div>

        {/* Tech Fashion Landing */}
        <div>
          <h3 className="text-black mb-8">Tech + Fashion Hybrid Brand</h3>
          <TechFashionLanding />
        </div>

        {/* Responsive Previews */}
        <div>
          <h3 className="text-black mb-8">Responsive Design System</h3>
          <ResponsivePreviews />
        </div>
      </div>
    </div>
  );
}
